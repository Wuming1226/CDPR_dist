// Usb_Can_DemoDlg.h : header file
//

#if !defined(AFX_USB_CAN_DEMODLG_H__6DE4AB35_B704_42CD_8A8E_1A1D87D0B0FF__INCLUDED_)
#define AFX_USB_CAN_DEMODLG_H__6DE4AB35_B704_42CD_8A8E_1A1D87D0B0FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <vector>
#include "./NiMotionUSBCAN/NiMotionUSBCAN.h"

/////////////////////////////////////////////////////////////////////////////
// CUsb_Can_DemoDlg dialog


class CUsb_Can_DemoDlg : public CDialog
{
// Construction
public:
	CUsb_Can_DemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CUsb_Can_DemoDlg)
	enum { IDD = IDD_USB_CAN_DEMO_DIALOG };
	CListCtrl	m_listFrames;
	CComboBox	m_comboDataLen;
	CComboBox	m_comboBaudrate;
	CComboBox	m_comboDevID;
	BOOL	m_isExtended;
	BOOL	m_isRemote;
	BOOL	m_isSRR;
	CString	m_strFrameID;
	CString	m_strFrameDatas;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUsb_Can_DemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CUsb_Can_DemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonSend();
	afx_msg void OnButtonClear();
	afx_msg void OnClose();
	afx_msg void OnButtonOpendevice();
	afx_msg void OnButtonClosedevice();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	void showFrame(const CAN_OBJ& frame);
	std::vector<CString> SplitString(const CString& strIn, TCHAR split = _T(' '));
	CString ByteArray2String(const BYTE array[], int size);
	int String2ByteArray(const CString& strIn, BYTE array[], int size);
	void Int2ByteArray(int val, BYTE array[], int size);
	int ByteArray2Int(const BYTE array[], int size);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_USB_CAN_DEMODLG_H__6DE4AB35_B704_42CD_8A8E_1A1D87D0B0FF__INCLUDED_)
