// Usb_Can_DemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Usb_Can_Demo.h"
#include "Usb_Can_DemoDlg.h"

#pragma comment(lib, "./NiMotionUSBCAN/NiMotionUSBCAN.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


BYTE Timing0[] = {0x31, 0x18, 0x09, 0x04, 0x03, 0x01, 0x00, 0x00, 0x00};
BYTE Timing1[] = {0x1C, 0x1C, 0x1C, 0x1C, 0x1C, 0x1C, 0x1C, 0x16, 0x14};

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsb_Can_DemoDlg dialog

CUsb_Can_DemoDlg::CUsb_Can_DemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUsb_Can_DemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUsb_Can_DemoDlg)
	m_isExtended = FALSE;
	m_isRemote = FALSE;
	m_isSRR = TRUE;
	m_strFrameID = _T("");
	m_strFrameDatas = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CUsb_Can_DemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUsb_Can_DemoDlg)
	DDX_Control(pDX, IDC_LIST_FRAMES, m_listFrames);
	DDX_Control(pDX, IDC_COMBO_DATASLEN, m_comboDataLen);
	DDX_Control(pDX, IDC_COMBO_BAUDRATE, m_comboBaudrate);
	DDX_Control(pDX, IDC_COMBO_DEVICEID, m_comboDevID);
	DDX_Check(pDX, IDC_CHECK_ISEXTENDED, m_isExtended);
	DDX_Check(pDX, IDC_CHECK_ISREMOTE, m_isRemote);
	DDX_Check(pDX, IDC_CHECK_SRR, m_isSRR);
	DDX_Text(pDX, IDC_EDIT_FRAMEID, m_strFrameID);
	DDX_Text(pDX, IDC_EDIT_FRAMEDATAS, m_strFrameDatas);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CUsb_Can_DemoDlg, CDialog)
	//{{AFX_MSG_MAP(CUsb_Can_DemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnButtonSend)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_OPENDEVICE, OnButtonOpendevice)
	ON_BN_CLICKED(IDC_BUTTON_CLOSEDEVICE, OnButtonClosedevice)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUsb_Can_DemoDlg message handlers

BOOL CUsb_Can_DemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_comboDevID.SetCurSel(0);
	m_comboBaudrate.SetCurSel(6);
	m_comboDataLen.SetCurSel(7);

	m_listFrames.InsertColumn(0, _T("ʱ���"), LVCFMT_LEFT, 150);
	m_listFrames.InsertColumn(1, _T("����"), LVCFMT_CENTER, 60);
	m_listFrames.InsertColumn(2, _T("����֡/Զ��֡"), LVCFMT_CENTER, 100);
	m_listFrames.InsertColumn(3, _T("��׼֡/��չ֡"), LVCFMT_CENTER, 100);
	m_listFrames.InsertColumn(4, _T("֡ID"), LVCFMT_RIGHT, 100);
	m_listFrames.InsertColumn(5, _T("֡����"), LVCFMT_LEFT, 300);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUsb_Can_DemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CUsb_Can_DemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUsb_Can_DemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CUsb_Can_DemoDlg::OnButtonSend() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	CAN_OBJ frame;
	memset(&frame, 0, sizeof(CAN_OBJ));
	frame.TimeStamp = 0;
	frame.TimeFlag = 0;
	frame.ExternFlag = (byte)(m_isExtended ? 1 : 0);
    frame.RemoteFlag = (byte)(m_isRemote ? 1 : 0);
	frame.SendType = (byte)(m_isSRR ? 2 : 0);
	BYTE frameIds[4] = {0};
	String2ByteArray(m_strFrameID, frameIds, 4);
	frame.ID = ByteArray2Int(frameIds, m_isExtended ? 4 : 2);
	frame.DataLen = m_comboDataLen.GetCurSel()+1;
	String2ByteArray(m_strFrameDatas, frame.Data, frame.DataLen);

	int devId = m_comboDevID.GetCurSel();
	if (STATUS_OK != NiM_Transmit(USBCAN1, devId, 0, &frame, 1))
	{
		MessageBox(_T("����ʧ��"), _T("��ʾ"));
	}
}

void CUsb_Can_DemoDlg::OnButtonClear() 
{
	// TODO: Add your control notification handler code here
	m_listFrames.DeleteAllItems();	
}

void CUsb_Can_DemoDlg::OnClose() 
{
	// TODO: Add your message handler code here and/or call default
	
	CDialog::OnClose();
}

void CUsb_Can_DemoDlg::OnButtonOpendevice() 
{
	// TODO: Add your control notification handler code here
	int devId = m_comboDevID.GetCurSel();
	if (STATUS_OK != NiM_OpenDevice(USBCAN1, devId, 0))
	{
		MessageBox(_T("�豸��ʧ��"), _T("��ʾ"));
		return;
	}
	INIT_CONFIG init_config;
	init_config.AccCode = 0;
	init_config.AccMask = 0xffffff;
	init_config.Filter = 0;
	init_config.Timing0 = Timing0[m_comboBaudrate.GetCurSel()];
	init_config.Timing1 = Timing1[m_comboBaudrate.GetCurSel()];
    init_config.Mode = 0;
	if (STATUS_OK != NiM_InitCAN(USBCAN1, devId, 0, &init_config))
	{
		NiM_CloseDevice(USBCAN1, devId);
		MessageBox(_T("�豸��ʼ��ʧ��"), _T("��ʾ"));
		return;
	}
	if (STATUS_OK != NiM_StartCAN(USBCAN1, devId, 0))
	{
		NiM_CloseDevice(USBCAN1, devId);
		MessageBox(_T("�豸����ʧ��"), _T("��ʾ"));
		return;
	}
	SetTimer(1, 50, NULL);
}

void CUsb_Can_DemoDlg::OnButtonClosedevice() 
{
	// TODO: Add your control notification handler code here
	KillTimer(1);
	int devId = m_comboDevID.GetCurSel();
	NiM_CloseDevice(USBCAN1, devId);
}

void CUsb_Can_DemoDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	CAN_OBJ frames[100];
	int devId = m_comboDevID.GetCurSel();
	int count = NiM_Receive(USBCAN1, devId, 0, frames, 100, 10);
	for (int i=0; i<count; i++)
	{
		showFrame(frames[i]);
	}
	
	CDialog::OnTimer(nIDEvent);
}


void CUsb_Can_DemoDlg::showFrame(const CAN_OBJ& frame)
{
	int curCount = m_listFrames.GetItemCount();
	m_listFrames.InsertItem(curCount, _T(""));

	int us = frame.TimeStamp%100000;
	int s = (frame.TimeStamp/100000)%60;
	int m = (frame.TimeStamp/100000/60)%60;
	int h = frame.TimeStamp/100000/60/60;
	CString strText;
	strText.Format("%02d:%02d%02d.%05d", h, m, s, us);
	m_listFrames.SetItemText(curCount, 0, strText);
	m_listFrames.SetItemText(curCount, 1, _T("����"));	
	m_listFrames.SetItemText(curCount, 2, frame.RemoteFlag>0?_T("Զ��֡"):_T("����֡"));
	m_listFrames.SetItemText(curCount, 3, frame.ExternFlag>0?_T("��չ֡"):_T("��׼֡"));
	BYTE frameIds[4] = {0};
	Int2ByteArray(frame.ID, frameIds, 4);
	m_listFrames.SetItemText(curCount, 4, ByteArray2String(frameIds, 4));
	m_listFrames.SetItemText(curCount, 5, ByteArray2String(frame.Data, frame.DataLen));
}

std::vector<CString> CUsb_Can_DemoDlg::SplitString(const CString& strIn, TCHAR split)
{
	std::vector<CString> vecSubStr;
	for (int start=0; start<strIn.GetLength(); start++)
	{
		if (strIn.GetAt(start) == split)
			continue;

		int end = start+1;
		for (; end<strIn.GetLength(); end++)
		{
			if (strIn.GetAt(end) != split)
				continue;

			break;
		}
		TRACE(_T("%s\r\n"), strIn.Mid(start, end-start));
		vecSubStr.push_back(strIn.Mid(start, end-start));
		start = end;
	}
	return vecSubStr;
}

CString CUsb_Can_DemoDlg::ByteArray2String(const BYTE array[], int size)
{
	CString str, strByte;
	for (int i=0; i<size; i++)
	{
		strByte.Format(_T("%02X "), array[i]);
		str += strByte;
	}
	str.TrimRight();
	return str;
}

int CUsb_Can_DemoDlg::String2ByteArray(const CString& strIn, BYTE array[], int size)
{
	int nCount = 0;
	std::vector<CString> strBytes = SplitString(strIn);
	TCHAR *pEnd;
	for (int i=0; i<strBytes.size() && i<size; i++)
	{
		array[i] = _tcstol(strBytes[i], &pEnd, 16);
		nCount++;
	}

	return nCount;
}

void CUsb_Can_DemoDlg::Int2ByteArray(int val, BYTE array[], int size)
{
	for (int i=0; i<4 && i<size; i++)
	{
		array[size-i-1] = (BYTE)(((UINT)val) >> (i*8));
	}
}

int CUsb_Can_DemoDlg::ByteArray2Int(const BYTE array[], int size)
{
	int val = 0;
	BYTE* pByte = (BYTE*)&val;
	for (int i=0; i<4 && i<size; i++)
	{
		pByte[size-i-1] = array[i];
	}
	return val;
}
